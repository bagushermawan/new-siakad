



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>403 - Siakad</title>


    <link rel="shortcut icon" href="<?php echo e(asset('/compiled/svg/favicon.svg')); ?>" type="image/x-icon">
    <link rel="stylesheet" href="<?php echo e(asset('/compiled/css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/compiled/css/error.css')); ?>">

</head>

<body>
    <script src="<?php echo e(asset('/static/js/initTheme.js')); ?>"></script>
    <div id="error">


        <div class="error-page container">
            <div class="col-md-8 col-12 offset-md-2">
                <div class="text-center">
                    <img class="img-error" src="<?php echo e(asset('/compiled/svg/error-403.svg')); ?>" alt="Forbidden">
                    <h1 class="error-title">Upss</h1>
                    <h4 class="text-gray-600">Maaf, sesi Anda telah berakhir.</h4>
                    <h4 class="text-gray-600">Harap muat ulang dan coba lagi.</h4>
                    <a onclick="goBack()" class="btn btn-lg btn-outline-primary mt-3">Kembali</a>
                </div>
            </div>
        </div>
        <script>
            function goBack() {
                window.location.href = '<?php echo e(route('login')); ?>';
            }
        </script>
</body>

</html>
<?php /**PATH C:\laragon\www\newsiakad\resources\views/errors/419.blade.php ENDPATH**/ ?>