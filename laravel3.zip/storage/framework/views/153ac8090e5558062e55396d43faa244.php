<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startPush('user-css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('extensions/datatables.net-bs5/css/dataTables.bootstrap5.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('compiled/css/table-datatable-jquery.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/extensions/moment/moment.min.js')); ?>">
    <style>
        html[data-bs-theme=dark] .text-sm {
            font-size: .775rem;
        }

        .profilepp {
            user-select: none;
            font-size: 1.5rem;
            margin-top: 0;
            margin-bottom: 0.5rem;
            font-weight: 700;
            line-height: 1.2;
            color: var(--bs-heading-color);
        }

        .profilepp2 {
            user-select: none;
            font-size: 1rem;
            margin-top: 0;
            margin-bottom: 0.5rem;
            font-weight: 700;
            line-height: 1.2;
            color: var(--bs-secondary-color);
        }

        @keyframes fadeIn {
            0% {
                opacity: 0;
            }

            100% {
                opacity: 1;
            }
        }

        .fade-in {
            animation: fadeIn 0.5s ease-in-out;
        }

        #userTable tbody tr {
            cursor: default;
        }

        #myTable tbody tr {
            cursor: default;
        }

        div.dataTables_wrapper div.dataTables_paginate ul.pagination{
            justify-content: center;
            margin: revert;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper container">
        <div class="page-title">
            <div class="row">
                <div class="col-12 col-md-6 order-md-1 order-last">
                    <h3>Dashboard <?php echo e(ucfirst(implode(', ', $roles->all()))); ?></h3>
                    
                </div>
            </div>
        </div>
        <div class="page-content">
            <div class="row">
                <?php if($santriId == null && auth()->user()->hasRole('wali santri')): ?>
                    
                    <?php echo $__env->make('user.partials.nosantri', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php elseif(auth()->user()->hasRole('user')): ?>
                    
                    <?php echo $__env->make('user.partials.santrilogin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php else: ?>
                    
                    <?php echo $__env->make('user.partials.walilogin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>

            </div>
            <section class="row">
                <div class="col-12 col-lg-4">
                    <div class="card" style="max-height: 425px; overflow-y: auto;" id="cardi">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h4>Riwayat Login</h4>
                            <div class="buttonsi">
                                <button class="btn icon" id="minimizeBtn"><i class="fas fa-minus"></i></button>
                                <button class="btn icon" id="closeBtn"><i class="fas fa-times"></i></button>
                            </div>
                        </div>
                        <!-- Menampilkan riwayat login dari users -->
                        <?php $__currentLoopData = $data_riwayat_login_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $riwayat_login): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card-content pb-4">
                                <div class="recent-message d-flex px-4 py-3">
                                    <div class="avatar avatar-xl">
                                        <img src="<?php echo e(asset('/compiled/jpg/1.jpg')); ?>" alt="" srcset="">
                                        <?php if($riwayat_login->status_login == true): ?>
                                            <span class="avatar-status bg-success"></span>
                                        <?php else: ?>
                                            <span class="avatar-status bg-danger"></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="name ms-4">
                                        <h5 class="mb-1"><?php echo e($riwayat_login->user->name); ?>

                                            <code>(<?php echo e($riwayat_login->user->roles->first()->name); ?>)</code>
                                        </h5>
                                        <h6 class="text-muted mb-0"><?php echo e($riwayat_login->user->email); ?></h6>
                                        <?php if($riwayat_login->status_login == false): ?>
                                            <span class="riwayat"><i class="far fa-clock"></i>&nbsp;
                                                <?php echo e($riwayat_login->updated_at->diffForHumans()); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <!-- Menampilkan riwayat login dari wali_santris -->
                        <?php $__currentLoopData = $data_riwayat_login_walis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $riwayat_login): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card-content pb-4">
                                <div class="recent-message d-flex px-4 py-3">
                                    <div class="avatar avatar-xl">
                                        <!-- Gantilah sesuai dengan atribut foto pada wali_santris -->
                                        <img src="<?php echo e(asset('/compiled/jpg/1.jpg')); ?>" alt="" srcset="">
                                        <?php if($riwayat_login->status_login == true): ?>
                                            <span class="avatar-status bg-success"></span>
                                        <?php else: ?>
                                            <span class="avatar-status bg-danger"></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="name ms-4">
                                        <h5 class="mb-1"><?php echo e($riwayat_login->waliSantri->name); ?>

                                            <code>(<?php echo e($riwayat_login->waliSantri->roles->first()->name); ?>)</code>
                                        </h5>
                                        <!-- Sesuaikan dengan atribut pada wali_santris yang ingin ditampilkan -->
                                        <h6 class="text-muted mb-0"><?php echo e($riwayat_login->waliSantri->email); ?>

                                        </h6>
                                        <?php if($riwayat_login->status_login == true): ?>
                                            <h6 class="text-muted mb-0" style="color:green !important;">Online
                                            </h6>
                                        <?php endif; ?>
                                        <?php if($riwayat_login->status_login == false): ?>
                                            <span class="riwayat"><i class="far fa-clock"></i>&nbsp;
                                                <?php echo e($riwayat_login->updated_at->diffForHumans()); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('user-script'); ?>
    <!-- Include Chart.js -->
    <script src="<?php echo e(asset('extensions/chart.js/chart.umd.min.js')); ?>"></script>
    <script src="<?php echo e(asset('extensions/chart.js/chartjs-plugin-datalabels.min.js')); ?>"></script>
    <script src="<?php echo e(asset('extensions/apexcharts/apexcharts.min.js')); ?>"></script>

    <script src="<?php echo e(asset('extensions/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('extensions/datatables.net-bs5/js/dataTables.bootstrap5.min.js')); ?>"></script>
    <?php echo $__env->make('user.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('user.datatables-wali', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('user.datatables-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('user.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\newsiakad\resources\views/user/dashboard.blade.php ENDPATH**/ ?>