<!doctype html>
<html>
    <head>
        <title>Laravel Notify</title>

    </head>
    <body style="background: rgb(112, 109, 109);">
ini coba notify

       
    </body>
</html>
