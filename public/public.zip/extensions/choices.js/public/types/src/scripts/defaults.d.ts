import { ClassNames } from './interfaces/class-names';
import { Options } from './interfaces/options';
export declare const DEFAULT_CLASSNAMES: ClassNames;
export declare const DEFAULT_CONFIG: Options;
//# sourceMappingURL=defaults.d.ts.map