<center>
    <a href='#' data-id="{{ $data->id }}" class="badge bg-primary tombol-edit">Edit</a> |
<a href='#' data-id="{{ $data->id }}" data-name={{ $data->name }} data-semester={{ $data->semester }} class="badge bg-danger tombol-del">Del</a>
</center>
