<center>
    <a href='#' data-id="{{ $data->id }}" class="badge bg-primary tombol-edit">Edit</a> |
<a href='#' data-id="{{ $data->id }}" data-name="{{ $data->user->name }}" class="badge bg-danger tombol-del">Del</a>
</center>
