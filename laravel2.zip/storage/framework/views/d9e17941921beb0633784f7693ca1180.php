



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>403 - Siakad</title>


    <link rel="shortcut icon" href="<?php echo e(asset('/compiled/svg/favicon.svg')); ?>" type="image/x-icon">
    <link rel="stylesheet" href="<?php echo e(asset('/compiled/css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/compiled/css/error.css')); ?>">

</head>

<body>
    <script src="<?php echo e(asset('/static/js/initTheme.js')); ?>"></script>
    <div id="error">


        <div class="error-page container">
            <div class="col-md-8 col-12 offset-md-2">
                <div class="text-center">
                    <img class="img-error" src="<?php echo e(asset('/compiled/svg/error-403.svg')); ?>" alt="Forbidden">
                    <h1 class="error-title">Upss</h1>
                    <p class="fs-5 text-gray-600"><?php echo e(__("$exception")); ?>.</p>

                    <?php if(Auth::guard('web')->check() || Auth::guard('wali')->check()): ?>
                        <!-- Jika sudah ada pengguna yang login dengan guard 'web' atau 'wali' -->
                        <a onclick="goBack()" class="btn btn-lg btn-outline-primary mt-3">Kembali</a>
                    <?php else: ?>
                        <!-- Jika tidak ada yang login atau tidak ada yang login dengan guard 'web' atau 'wali' -->
                        <a onclick="goBack()" class="btn btn-lg btn-outline-primary mt-3">Login</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <script>
            function goBack() {
                window.location.href = '<?php echo e(route('login')); ?>';
            }
        </script>
</body>

</html>
<?php /**PATH C:\laragon\www\newsiakad\resources\views/errors/403.blade.php ENDPATH**/ ?>