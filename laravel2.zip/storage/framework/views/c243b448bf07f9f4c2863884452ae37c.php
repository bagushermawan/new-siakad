<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - Siakad</title>



    <link rel="shortcut icon" href="<?php echo e(asset('/compiled/svg/favicon.svg')); ?>" type="image/x-icon">
    <link rel="stylesheet" href="<?php echo e(asset('/compiled/css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/compiled/css/app-dark.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/compiled/css/auth.css')); ?>">
</head>

<body>
    <script src="<?php echo e(asset('/static/js/initTheme.js')); ?>"></script>
    <div id="auth">
        <!-- Session Status -->

        <div class="row h-100">
            <div class="col-lg-5 col-12">
                <div id="auth-left">
                    <div class="auth-logo">
                        <a href="index.html"><img src="<?php echo e(asset('/compiled/svg/logo.svg')); ?>" alt="Logo"></a>
                    </div>
                    <h1 class="auth-title">Forgot Password?</h1>
                    <p class="auth-subtitle mb-5">No problem. Just let us know your email address and we will email you
                        a password reset link that will allow you to choose a new one.</p>

                    <form method="POST" action="<?php echo e(route('password.email')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group position-relative has-icon-left mb-4">
                            <input type="email" class="form-control form-control-xl" placeholder="Email"
                                id="email" name="email" :value="old('email')" autofocus>
                            <div class="form-control-icon">
                                <i class="bi bi-envelope"></i>
                            </div>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="auth-subtitle mb-5" style="color:#F8719D;"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <?php if(session('status')): ?>
                            <div class="auth-subtitle mb-5" style="color:#198754;">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <button class="btn btn-primary btn-block btn-lg shadow-lg mt-5">Send</button>
                    </form>
                    <div class="text-center mt-5 text-lg fs-4">
                        <p class='text-gray-600'>Remember your account? <a href="<?php echo e(route('login')); ?>" class="font-bold">Log
                                in</a>.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-lg-7 d-none d-lg-block">
                <div id="auth-right">

                </div>
            </div>
        </div>

    </div>
</body>

</html>
<?php /**PATH C:\laragon\www\newsiakad\resources\views/auth/forgot-password.blade.php ENDPATH**/ ?>