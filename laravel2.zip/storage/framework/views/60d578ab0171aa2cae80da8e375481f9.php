<center>
    <a href='#' data-id="<?php echo e($data->id); ?>" class="badge bg-primary tombol-edit">Edit</a> |
<a href='#' data-id="<?php echo e($data->id); ?>" data-name="<?php echo e($data->user->name); ?>" class="badge bg-danger tombol-del">Del</a>
</center>
<?php /**PATH C:\laragon\www\newsiakad\resources\views/admin/nilai/tombol.blade.php ENDPATH**/ ?>