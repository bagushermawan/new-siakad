<center>
    <a href='#' data-id="<?php echo e($data->id); ?>" data-user-type="<?php echo e($data->user_type); ?>" class="badge bg-primary tombol-edit">Edit</a> |
    <a href='#' data-id="<?php echo e($data->id); ?>" data-user-type="<?php echo e($data->user_type); ?>" data-name="<?php echo e($data->name); ?>" class="badge bg-danger tombol-del">Del</a>
</center>
<?php /**PATH C:\laragon\www\newsiakad\resources\views/admin/tombol.blade.php ENDPATH**/ ?>