<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startPush('user-css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('extensions/datatables.net-bs5/css/dataTables.bootstrap5.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('compiled/css/table-datatable-jquery.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/extensions/moment/moment.min.js')); ?>">
    <style>
        html[data-bs-theme=dark] .text-sm {
            font-size: .775rem;
        }

        .profilepp {
            user-select: none;
            font-size: 1.5rem;
            margin-top: 0;
            margin-bottom: 0.5rem;
            font-weight: 700;
            line-height: 1.2;
            color: var(--bs-heading-color);
        }

        @keyframes fadeIn {
            0% {
                opacity: 0;
            }

            100% {
                opacity: 1;
            }
        }

        .fade-in {
            animation: fadeIn 0.5s ease-in-out;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper container">
        <div class="page-title">
            <div class="row">
                <div class="col-12 col-md-6 order-md-1 order-last">
                    <h3>Dashboard <?php echo e(ucfirst(implode(', ', $roles->all()))); ?></h3>
                    
                </div>
            </div>
        </div>
        <div class="page-content">
            <div class="row">
                <?php if($santriId == null): ?>
                    
                    <div class="col-7">
                        <div class="card">
                            <div class="card-header">
                                <div class="card-title">
                                    <h4>Hubungkan Santri</h4>
                                </div>
                            </div>
                            <div class="d-flex justify-content-center align-items-center flex-column">
                                <div class="avatar avatar-3xl">
                                    <img src="<?php echo e(asset('compiled/svg/addsantri.svg')); ?>" alt="Avatar" id="fotoPondok">
                                </div>
                            </div>
                            <div class="card-body">
                                <form method="post" action="<?php echo e(route('search-santri')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <h6>Username:</h6>
                                    <div class="form-group position-relative has-icon-left">
                                        <input type="text" class="form-control" name="username">
                                        <div class="form-control-icon">
                                            <i class="bi bi-person"></i>
                                        </div>
                                    </div>

                                    <h6>No HP:</h6>
                                    <div class="form-group position-relative has-icon-left">
                                        <input type="number" class="form-control" name="nohp">
                                        <div class="form-control-icon">
                                            <i class="fas fa-mobile-alt"></i>
                                        </div>
                                    </div>
                                    <code>Pastikan siswa sudah memiliki akun dan terhubung dengan sekolah</code>
                                    <?php if(session('error')): ?>
                                        <div class="alert alert-danger alert-dismissible fade show">
                                            <?php echo e(session('error')); ?>

                                            <button type="button" class="btn-close" data-bs-dismiss="alert"
                                                aria-label="Close"></button>
                                        </div>
                                    <?php endif; ?>
                                    <div class="form-group position-relative">
                                        <button class="form-control btn btn-primary" type="submit">SEARCH</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="col-5">
                        <div class="card">
                            <div class="card-header">
                                <div class="card-title">
                                    <h4>Informasi Data Santri Anda</h4>
                                </div>
                            </div>
                            <div class="d-flex justify-content-center align-items-center flex-column">
                                <div class="avatar avatar-3xl">
                                    <?php if($fotoSantri != ''): ?>
                                        <img src="<?php echo e(asset('storage/' . $fotoSantri)); ?>" alt="Avatar" id="fotoPondok">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('/compiled/jpg/1.jpg')); ?>" alt="Avatar"><?php echo e($fotoSantri); ?>

                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="table-responsive" style="margin-top: 3rem;">
                                <table class="table table-borderless table-lg">
                                    <tbody>
                                        <tr>
                                            <td class="col-4">
                                                <div class="d-flex align-items-center">
                                                    <p class="font-bold h6 mb-0">NISN</p>
                                                </div>
                                            </td>
                                            <td class="col-auto">
                                                <p class=" mb-0"><span class="profilepp" style="margin-left: 1rem">
                                                        : <?php echo e($nisnSantri); ?>

                                                    </span>
                                                </p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="col-4">
                                                <div class="d-flex align-items-center">
                                                    <p class="font-bold h6 mb-0">Nama Santri</p>
                                                </div>
                                            </td>
                                            <td class="col-auto">
                                                <p class=" mb-0">
                                                    <span class="profilepp" style="margin-left: 1rem">
                                                        : <?php echo e($namaSantri); ?>

                                                    </span>
                                                </p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="col-4">
                                                <div class="d-flex align-items-center">
                                                    <p class="font-bold h6 mb-0">Username Santri</p>
                                                </div>
                                            </td>
                                            <td class="col-auto">
                                                <p class=" mb-0">
                                                    <span class="profilepp" style="margin-left: 1rem">
                                                        : <?php echo e($usernameSantri); ?>

                                                    </span>
                                                </p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="col-4">
                                                <div class="d-flex align-items-center">
                                                    <p class="font-bold h6 mb-0">Kelas Santri</p>
                                                </div>
                                            </td>
                                            <td class="col-auto">
                                                <p class=" mb-0">
                                                    <span class="profilepp" style="margin-left: 1rem">
                                                        : <?php echo e($kelasSantri); ?>

                                                    </span>
                                                </p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="col-4">
                                                <div class="d-flex align-items-center">
                                                    <p class="font-bold h6 mb-0">Telepon Santri</p>
                                                </div>
                                            </td>
                                            <td class="col-auto">
                                                <p class=" mb-0"><span class="profilepp" style="margin-left: 1rem">:
                                                        <?php echo e($nohpSantri); ?></span>
                                                </p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="col-4">
                                                <div class="d-flex align-items-center">
                                                    <p class="font-bold h6 mb-0">Email Santri</p>
                                                </div>
                                            </td>
                                            <td class="col-auto">
                                                <p class=" mb-0"><span class="profilepp" style="margin-left: 1rem">:
                                                        <?php echo e($emailSantri); ?></span>
                                                </p>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="col-7">
                        <div class="card">
                            <div class="card-header">
                                <div class="card-title">
                                    <h6 class="d-flex justify-content-between align-items-center">
                                        <span>Tahun Ajaran: <b><?php echo e($thaktif->name); ?></b></span>
                                        <div class="ml-auto">Semester:
                                            <select class="" id="filterTahunAjaran">
                                                <option value="">Semester</option>
                                            </select>
                                        </div>

                                    </h6>
                                </div>
                            </div>

                            <div class="table-responsive">
                                <table class="table table-borderless" id="myTable">
                                    
                                </table>
                                <a onclick="refreshDataTable();"
                                    class="btn icon icon-left d-flex justify-content-center align-items-center">
                                    <span id="refreshText">REFRESH</span>
                                    <i id="refreshIcon" class="fas fa-sync fa-spin d-none"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

            </div>
            <section class="row">
                <div class="col-12 col-lg-3">
                    <div class="card" style="max-height: 425px; overflow-y: auto;" id="cardi">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h4>Riwayat Login</h4>
                            <div class="buttonsi">
                                <button class="btn icon" id="minimizeBtn"><i class="fas fa-minus"></i></button>
                                <button class="btn icon" id="closeBtn"><i class="fas fa-times"></i></button>
                            </div>
                        </div>
                        <!-- Menampilkan riwayat login dari users -->
                        <?php $__currentLoopData = $data_riwayat_login_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $riwayat_login): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card-content pb-4">
                                <div class="recent-message d-flex px-4 py-3">
                                    <div class="avatar avatar-xl">
                                        <img src="<?php echo e(asset('/compiled/jpg/1.jpg')); ?>" alt="" srcset="">
                                        <?php if($riwayat_login->status_login == true): ?>
                                            <span class="avatar-status bg-success"></span>
                                        <?php else: ?>
                                            <span class="avatar-status bg-danger"></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="name ms-4">
                                        <h5 class="mb-1"><?php echo e($riwayat_login->user->name); ?>

                                            <code>(<?php echo e($riwayat_login->user->roles->first()->name); ?>)</code>
                                        </h5>
                                        <h6 class="text-muted mb-0"><?php echo e($riwayat_login->user->email); ?></h6>
                                        <?php if($riwayat_login->status_login == false): ?>
                                            <span class="riwayat"><i class="far fa-clock"></i>&nbsp;
                                                <?php echo e($riwayat_login->updated_at->diffForHumans()); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <!-- Menampilkan riwayat login dari wali_santris -->
                        <?php $__currentLoopData = $data_riwayat_login_walis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $riwayat_login): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card-content pb-4">
                                <div class="recent-message d-flex px-4 py-3">
                                    <div class="avatar avatar-xl">
                                        <!-- Gantilah sesuai dengan atribut foto pada wali_santris -->
                                        <img src="<?php echo e(asset('/compiled/jpg/1.jpg')); ?>" alt="" srcset="">
                                        <?php if($riwayat_login->status_login == true): ?>
                                            <span class="avatar-status bg-success"></span>
                                        <?php else: ?>
                                            <span class="avatar-status bg-danger"></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="name ms-4">
                                        <h5 class="mb-1"><?php echo e($riwayat_login->waliSantri->name); ?>

                                            <code>(<?php echo e($riwayat_login->waliSantri->roles->first()->name); ?>)</code>
                                        </h5>
                                        <!-- Sesuaikan dengan atribut pada wali_santris yang ingin ditampilkan -->
                                        <h6 class="text-muted mb-0"><?php echo e($riwayat_login->waliSantri->email); ?>

                                        </h6>
                                        <?php if($riwayat_login->status_login == true): ?>
                                            <h6 class="text-muted mb-0" style="color:green !important;">Online
                                            </h6>
                                        <?php endif; ?>
                                        <?php if($riwayat_login->status_login == false): ?>
                                            <span class="riwayat"><i class="far fa-clock"></i>&nbsp;
                                                <?php echo e($riwayat_login->updated_at->diffForHumans()); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('user-script'); ?>
    <!-- Include Chart.js -->
    <script src="<?php echo e(asset('extensions/chart.js/chart.umd.min.js')); ?>"></script>
    <script src="<?php echo e(asset('extensions/chart.js/chartjs-plugin-datalabels.min.js')); ?>"></script>
    <script src="<?php echo e(asset('extensions/apexcharts/apexcharts.min.js')); ?>"></script>

    <script src="<?php echo e(asset('extensions/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('extensions/datatables.net-bs5/js/dataTables.bootstrap5.min.js')); ?>"></script>
    <?php echo $__env->make('user.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('user.datatables', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('user.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\newsiakad\resources\views/user/dashboard.blade.php ENDPATH**/ ?>