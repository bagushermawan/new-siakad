<?php $__env->startSection('title', 'Siswa'); ?>
<?php $__env->startPush('page-css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('extensions/datatables.net-bs5/css/dataTables.bootstrap5.min.css')); ?>">


    <link rel="stylesheet" href="<?php echo e(asset('compiled/css/table-datatable-jquery.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/extensions/choices.js/public/assets/styles/choices.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/extensions/@fortawesome/fontawesome-free/css/all.min.css')); ?>">
    <style>
        .wajib {
            color: #dc3545;
        }

        .form-control.pw::placeholder {
            color: #495057 !important;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-heading">
        <div class="page-title">
            <div class="row">
                <div class="col-12 col-md-6 order-md-1 order-last">
                    <h3>Data Siswa</h3>
                    <p class="text-subtitle text-muted">A sortable, searchable, paginated table without dependencies thanks
                        to simple-datatables.</p>
                </div>
                <div class="col-12 col-md-6 order-md-2 order-first">
                    <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
                            <li class="breadcrumb-item" aria-current="page">User
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
        <section class="section">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title">
                        Ajax CRUD Datatables
                    </h5>
                    <?php if(auth()->user()->hasRole('admin')): ?>
                        <h6>
                            <a href="#" class="btn icon icon-left btn-success tombol-tambah"><svg
                                    xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                    fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round" class="feather feather-edit">
                                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                                </svg> Tambah Data</a>
                        </h6>
                        <div id="totalSantri" data-total="<?php echo e($totalSantri); ?>"></div>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped" id="myTable">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    
                                    <th>NISN</th>
                                    <th>NIS</th>
                                    <th>Name</th>
                                    <th>Username</th>
                                    <th>Tanggal Lahir</th>
                                    <th>Kelas</th>
                                    <th>Status</th>
                                    
                                    
                                    <th>
                                        <center>Roles</center>
                                    </th>
                                    <th>
                                        Foto User
                                    </th>
                                    <th>
                                        <center>Action</center>
                                    </th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>




        </section>
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="myModalLabel33">Form Tambah Data User </h4>
                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                stroke-linejoin="round" class="feather feather-x">
                                <line x1="18" y1="6" x2="6" y2="18"></line>
                                <line x1="6" y1="6" x2="18" y2="18"></line>
                            </svg>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="alert alert-danger d-none"></div>
                        
                        <label>NISN<span class="wajib">*</span>: </label>
                        <div class="form-group">
                            <input id="nisn" type="text" name="nisn" class="form-control" autofocus>
                        </div>
                        <label>NIS<span class="wajib">*</span>: </label>
                        <div class="form-group">
                            <input id="nis" type="text" name="nis" class="form-control" autofocus>
                        </div>
                        <label>Nama<span class="wajib">*</span>: </label>
                        <div class="form-group">
                            <input id="name" type="text" name="name" class="form-control" autofocus>
                        </div>
                        <label>Username<span class="wajib">*</span>: </label>
                        <div class="form-group">
                            <input id="username" type="text" name="username" class="form-control"
                                placeholder="Username default sama dengan nama">
                        </div>
                        <label>Tanggal Lahir<span class="wajib">*</span>: </label>
                        <div class="form-group">
                            <input id="tanggal_lahir" type="date" name="tanggal_lahir" class="form-control">
                        </div>
                        <label>Kelas: </label>
                        <div class="form-group">
                            <select class="form-control" id="kelas_id" name="kelas_id" required>
                                
                                <option value="">Pilih Kelas</option>
                                <?php $__currentLoopData = $kelasOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($kelas->id); ?>"><?php echo e($kelas->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <label>Status<span class="wajib">*</span>: </label>
                        <div class="form-group">
                            <select class="form-control" id="status_siswa" name="status_siswa" required>
                                
                                <option value="">Pilih Status</option>
                                <option value="aktif">Aktif</option>
                                <option value="tidak aktif">Tidak Aktif</option>
                                <option value="lulus">Lulus</option>
                                <option value="pindahan">Pindahan</option>
                            </select>
                        </div>
                        <label>Email<span class="wajib">*</span>: </label>
                        <div class="form-group">
                            <input id="email" type="text" name="email" class="form-control">
                        </div>
                        
                        <label>Roles: </label>
                        <div class="form-group">
                            <select id="role" name="role" class="form-control">
                                
                                <?php if(count($roless) >= 2): ?>
                                    <option value="<?php echo e($roless[3]->name); ?>" selected><?php echo e(ucfirst($roless[3]->name)); ?>

                                    </option>
                                <?php endif; ?>
                            </select>
                        </div>

                        <label>Password: </label>
                        <div class="form-group">
                            <input id="password" type="password" name="password" class="form-control"
                                placeholder="Password default sama dengan Username">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light-secondary" data-bs-dismiss="modal">
                            <i class="bx bx-x d-block d-sm-none"></i>
                            <span class="d-none d-sm-block">Close</span>
                        </button>
                        <button type="button" class="btn btn-primary ms-1" data-bs-dismiss="modal">
                            <i class="bx bx-check d-block d-sm-none"></i>
                            <span class="d-none d-sm-block tombol-simpan">Save</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="modal fade" id="statusModal" tabindex="-1" aria-labelledby="statusModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="myModalLabel33">Form Edit Status User </h4>
                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                stroke-linejoin="round" class="feather feather-x">
                                <line x1="18" y1="6" x2="6" y2="18"></line>
                                <line x1="6" y1="6" x2="18" y2="18"></line>
                            </svg>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="alert alert-danger d-none"></div>
                        
                        <div style="display:none;">
                        <label>NISN<span class="wajib">*</span>: </label>
                        <div class="form-group">
                            <input id="nisnn" type="text" name="nisn" class="form-control" disabled>
                        </div>
                        <label>NIS<span class="wajib">*</span>: </label>
                        <div class="form-group">
                            <input id="niss" type="text" name="nis" class="form-control" disabled>
                        </div>
                        <label>Tanggal Lahir<span class="wajib">*</span>: </label>
                        <div class="form-group">
                            <input id="tanggal_lahirr" type="date" name="tanggal_lahir" class="form-control" disabled>
                        </div>
                        <label>Kelas: </label>
                        <div class="form-group">
                            <select class="form-control" id="kelas_idd" name="kelas_id" disabled>
                                
                                <option value="">Pilih Kelas</option>
                                <?php $__currentLoopData = $kelasOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($kelas->id); ?>"><?php echo e($kelas->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <label>Email<span class="wajib">*</span>: </label>
                        <div class="form-group">
                            <input id="emaill" type="text" name="email" class="form-control" disabled>
                        </div>
                        <label>Roles: </label>
                        <div class="form-group">
                            <select id="rolee" name="role" class="form-control" disabled>
                                
                                    <option value="user" selected>user</option>
                            </select>
                        </div>
                        <label>Password: </label>
                        <div class="form-group">
                            <input id="passwordd" type="password" name="password" class="form-control"
                                placeholder="Password default sama dengan Username">
                        </div>
                        </div>
                        <label>Nama<span class="wajib">*</span>: </label>
                        <div class="form-group">
                            <input id="namee" type="text" name="name" class="form-control" disabled>
                        </div>
                        <label>Username<span class="wajib">*</span>: </label>
                        <div class="form-group">
                            <input id="usernamee" type="text" name="username" class="form-control"
                                placeholder="Username default sama dengan nama" disabled>
                        </div>
                        <label>Status<span class="wajib">*</span>: </label>
                        <div class="form-group">
                            <select class="form-control" id="status_siswaa" name="status_siswa" required>
                                
                                <option value="">Pilih Status</option>
                                <option value="aktif">Aktif</option>
                                <option value="tidak aktif">Tidak Aktif</option>
                                <option value="lulus">Lulus</option>
                                <option value="pindahan">Pindahan</option>
                            </select>
                        </div>
                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light-secondary" data-bs-dismiss="modal">
                            <i class="bx bx-x d-block d-sm-none"></i>
                            <span class="d-none d-sm-block">Close</span>
                        </button>
                        <button type="button" class="btn btn-primary ms-1" data-bs-dismiss="modal">
                            <i class="bx bx-check d-block d-sm-none"></i>
                            <span class="d-none d-sm-block tombol-simpan">Save</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('page-script'); ?>
    <script src="<?php echo e(asset('extensions/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('extensions/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('extensions/datatables.net-bs5/js/dataTables.bootstrap5.min.js')); ?>"></script>

    <script src="<?php echo e(asset('extensions/datatables.net/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('extensions/datatables.net/js/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('extensions/datatables.net/js/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('extensions/datatables.net/js/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('extensions/datatables.net/js/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('extensions/datatables.net/js/buttons.print.min.js')); ?>"></script>

    <?php echo $__env->make('admin.user.siswa.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="<?php echo e(asset('/extensions/choices.js/public/assets/scripts/choices.min.js')); ?>"></script>
    <script>
        // Inisialisasi objek Choices.js baru
        var roleSelect = new Choices('#role', {
            searchEnabled: false,
            itemSelectText: '',
            allowHTML: true,
        });
    </script>
    <script>
        document.getElementById("name").addEventListener("input", function() {
            var nameValue = this.value.trim().toLowerCase();
            var usernameInput = document.getElementById("username");
            var cleanedName = nameValue.replace(/\W+/g, '');
            var nameParts = cleanedName.split(' ');
            var usernameValue = nameParts[0];
            if (nameParts.length > 1) {
                usernameValue += nameParts[1];
            }
            usernameInput.value = usernameValue;
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\newsiakad\resources\views/admin/user/siswa/index.blade.php ENDPATH**/ ?>