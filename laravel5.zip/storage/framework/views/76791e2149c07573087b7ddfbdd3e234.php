<?php $__env->startSection('title', 'Jadwal Mata Pelajaran'); ?>
<?php $__env->startPush('page-css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('extensions/datatables.net-bs5/css/dataTables.bootstrap5.min.css')); ?>">


    <link rel="stylesheet" href="<?php echo e(asset('compiled/css/table-datatable-jquery.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/extensions/choices.js/public/assets/styles/choices.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/extensions/flatpickr/flatpickr.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/extensions/@fortawesome/fontawesome-free/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/extensions/moment/moment.min.js')); ?>">
    
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-heading">
        <div class="page-title">
            <div class="row">
                <div class="col-12 col-md-6 order-md-1 order-last">
                    <h3>Data Nilai</h3>
                    <p class="text-subtitle text-muted">A sortable, searchable, paginated table without dependencies thanks
                        to simple-datatables.</p>
                </div>
                <div class="col-12 col-md-6 order-md-2 order-first">
                    <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
                            <li class="breadcrumb-item" aria-current="page">User
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
        <section class="section">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title">
                        CRUD Datatables
                    </h5>
                    <?php if(auth()->user()->hasRole('admin')): ?>
                        <h6 style="float: left;">
                            <a href="#" class="btn icon icon-left btn-success tombol-tambah"><svg
                                    xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                    fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round" class="feather feather-edit">
                                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                                </svg> Tambah Data</a>
                        </h6>
                        <div id="totalNilai" data-total="<?php echo e($total_nilai); ?>"></div>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    
                    <div class="row">
                        <h6>Filter</h6>
                        <p>Pilih filter berdasarkan <code>Santri</code>, <code>Kelas</code> atau <code>Mata Pelajaran</code></p>
                        <div class="col-sm-3 mb-1">
                            <div class="input-group mb-3">
                                <label class="input-group-text" for="filterSantri">Santri</label>
                                <select class="form-select" id="filterSantri">
                                    <option value="">Semua Santri</option>
                                </select>
                                <button class="input-group-text" id="clearFilterSantri" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Hapus filter Santri">x</button>
                            </div>
                        </div>

                        <div class="col-sm-3 mb-1">
                            <div class="input-group mb-3">
                                <label class="input-group-text" for="filterKelas">Kelas</label>
                                <select class="form-select" id="filterKelas">
                                    <option value="">Semua Kelas</option>
                                </select>
                                <button class="input-group-text" id="clearFilterKelas" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Hapus filter Kelas">x</button>
                            </div>
                        </div>

                        <div class="col-sm-5 mb-1">
                            <div class="input-group mb-3">
                                <label class="input-group-text" for="filterMataPelajaran">Mata Pelajaran</label>
                                <select class="form-select" id="filterMataPelajaran">
                                    <option value="">Semua Mata Pelajaran</option>
                                </select>
                                <button class="input-group-text" id="clearFilterMataPelajaran" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Hapus filter Mata Pelajaran">x</button>
                            </div>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-striped" id="myTable">
                            <thead>
                                <tr>
                                    <th class="col-md-1">
                                        <center>No</center>
                                    </th>
                                    <th class="col-md-2">Nama Santri</th>
                                    <th>Mata Pelajaran</th>
                                    <th>Kelas</th>
                                    <th>Tahun Ajaran</th>
                                    <th>Nilai</th>
                                    <th>Created at</th>
                                    <th>
                                        <center>Action</center>
                                    </th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>

        </section>
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="myModalLabel33">Form Tambah Jadwal Mata Pelajaran </h4>
                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                stroke-linejoin="round" class="feather feather-x">
                                <line x1="18" y1="6" x2="6" y2="18"></line>
                                <line x1="6" y1="6" x2="18" y2="18"></line>
                            </svg>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="alert alert-danger d-none"></div>
                        
                        <label>Santri: </label>
                        <div class="form-group">
                            <select id="user_id" name="user_id" class="form-control">
                                <option value="">Pilih Santri</option>
                                <?php $__currentLoopData = $santri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($a->id); ?>"><?php echo e($a->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <label>Mata Pelajaran: </label>
                        <div class="form-group">
                            <select id="mata_pelajaran_id" name="mata_pelajaran_id" class="form-control">
                                <option value="">Pilih Mata Pelajaran</option>
                                <?php $__currentLoopData = $matpel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($a->id); ?>"><?php echo e($a->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>


                        <label>Kelas: </label>
                        <div class="form-group">
                            <select id="kelas_id" name="kelas_id" class="form-control">
                                <option value="">Pilih Kelas</option>
                                <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($kelas->id); ?>"><?php echo e($kelas->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <label>Tahun Ajaran:</label>
                        <div class="form-group">
                            <select id="tahun_ajaran_id" name="tahun_ajaran_id" class="form-control">
                                <option value="">Pilih Tahun Ajaran</option>
                                <?php $__currentLoopData = $tahunajaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($a->id); ?>" <?php if($a->status != 'aktif'): ?> disabled <?php endif; ?>>
                                        <?php echo e($a->name); ?> - <?php echo e($a->semester); ?> - <?php echo e($a->status); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <label>Nilai: </label>
                        <div class="form-group">
                            <input id="nilai" type="number" step="0.1" name="nilai" class="form-control"
                                autofocus>
                        </div>


                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light-secondary" data-bs-dismiss="modal">
                            <i class="bx bx-x d-block d-sm-none"></i>
                            <span class="d-none d-sm-block">Close</span>
                        </button>
                        <button type="button" class="btn btn-primary ms-1" data-bs-dismiss="modal">
                            <i class="bx bx-check d-block d-sm-none"></i>
                            <span class="d-none d-sm-block tombol-simpan">Save</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('page-script'); ?>
    <script src="<?php echo e(asset('extensions/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('extensions/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('extensions/datatables.net-bs5/js/dataTables.bootstrap5.min.js')); ?>"></script>

    <script src="<?php echo e(asset('extensions/datatables.net/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('extensions/datatables.net/js/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('extensions/datatables.net/js/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('extensions/datatables.net/js/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('extensions/datatables.net/js/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('extensions/datatables.net/js/buttons.print.min.js')); ?>"></script>

    <?php echo $__env->make('admin.nilai.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="<?php echo e(asset('/extensions/choices.js/public/assets/scripts/choices.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\newsiakad\resources\views/admin/nilai/index.blade.php ENDPATH**/ ?>