<div class="col-12 col-lg-7">
    <div class="card">
        <div class="card-header">
            <div class="card-title">
                <h4>Hubungkan Santri</h4>
            </div>
        </div>
        <div class="d-flex justify-content-center align-items-center flex-column">
            <div class="avatar avatar-3xl">
                <img src="<?php echo e(asset('compiled/svg/addsantri.svg')); ?>" alt="Avatar" id="fotoPondok">
            </div>
        </div>
        <div class="card-body">
            <form method="post" action="<?php echo e(route('search-santri')); ?>">
                <?php echo csrf_field(); ?>
                <h6>Username:</h6>
                <div class="form-group position-relative has-icon-left">
                    <input type="text" class="form-control" name="username" :value="old('username')"
                        placeholder="Masukkan Username Santri">
                    <div class="form-control-icon">
                        <i class="fas fa-at"></i>
                    </div>
                    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div style="color:#F8719D;"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <h6>No HP:</h6>
                <div class="form-group position-relative has-icon-left">
                    <input type="number" class="form-control" name="nohp" :value="old('nohp')"
                        placeholder="Masukkan No.HP Santri">
                    <div class="form-control-icon">
                        <i class="fas fa-mobile-alt"></i>
                    </div>
                    <?php $__errorArgs = ['nohp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div style="color:#F8719D;"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <code>Pastikan siswa sudah memiliki akun dan terhubung dengan sekolah</code>
                <?php $__errorArgs = ['error'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <?php echo e($message); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="form-group position-relative">
                    <button class="form-control btn btn-primary" type="submit">SEARCH</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\newsiakad\resources\views/user/partials/nosantri.blade.php ENDPATH**/ ?>