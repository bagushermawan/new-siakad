<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startPush('user-css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('extensions/datatables.net-bs5/css/dataTables.bootstrap5.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('compiled/css/table-datatable-jquery.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/extensions/moment/moment.min.js')); ?>">
    <style>
        html[data-bs-theme=dark] .text-sm {
            font-size: .775rem;
        }

        .profilepp {
            user-select: none;
            font-size: 1.5rem;
            margin-top: 0;
            margin-bottom: 0.5rem;
            font-weight: 700;
            line-height: 1.2;
            color: var(--bs-heading-color);
        }

        @keyframes fadeIn {
            0% {
                opacity: 0;
            }

            100% {
                opacity: 1;
            }
        }

        .fade-in {
            animation: fadeIn 0.5s ease-in-out;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper container">
        <div class="page-title">
            <div class="row">
                <div class="col-12 col-md-6 order-md-1 order-last">
                    <h3>Dashboard <?php echo e(ucfirst(implode(', ', $roles->all()))); ?></h3>
                    
                </div>
            </div>
        </div>
        <div class="page-content">
            <div class="row">
                <?php if($santriId == null): ?>
                    
                    <div class="col-12 col-lg-7">
                        <div class="card">
                            <div class="card-header">
                                <div class="card-title">
                                    <h4>Hubungkan Santri</h4>
                                </div>
                            </div>
                            <div class="d-flex justify-content-center align-items-center flex-column">
                                <div class="avatar avatar-2xl">
                                    <?php if($santri->foto_user != null): ?>
                                        <img src="<?php echo e(asset('storage/' . $santri->foto_user)); ?>" alt="Avatar"
                                            id="fotoPondok">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('/compiled/jpg/7.jpg')); ?>" alt="Avatar">
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="card-body" style="margin-top: 3rem;">
                                <div class="form-group">
                                    <h6>Nama Santri: <?php echo e($santri->name); ?></h6>
                                </div>
                                <div class="form-group">
                                    <h6>Username: <?php echo e($santri->username); ?></h6>
                                </div>
                                <div class="form-group">
                                    <h6>Kelas: <?php echo e(optional($santri->kelas)->name); ?></h6>
                                </div>
                                <div class="form-group">
                                    <h6>No HP: <?php echo e($santri->nohp); ?></h6>
                                </div>
                                <form method="post" action="<?php echo e(route('hubungkan-santri', ['santriId' => $santri->id])); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group position-relative">
                                        <button class="form-control btn btn-outline-success"
                                            type="submit">HUBUNGKAN</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="col-5">
                        <div class="card">
                            <div class="card-header">
                                <div class="card-title">
                                    <h4>Informasi Data Santri Anda</h4>
                                </div>
                            </div>
                            <div class="d-flex justify-content-center align-items-center flex-column">
                                <div class="avatar avatar-3xl">
                                    <img src="<?php echo e(asset('storage/' . $fotoSantri)); ?>" alt="Avatar" id="fotoPondok">
                                </div>
                            </div>
                            <div class="table-responsive" style="margin-top: 3rem;">
                                <table class="table table-borderless table-lg">
                                    <tbody>
                                        <tr>
                                            <td class="col-4">
                                                <div class="d-flex align-items-center">
                                                    <p class="font-bold h6 mb-0">NISN</p>
                                                </div>
                                            </td>
                                            <td class="col-auto">
                                                <p class=" mb-0"><span class="profilepp" style="margin-left: 1rem">
                                                        : <?php echo e($nisnSantri); ?>

                                                    </span>
                                                </p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="col-4">
                                                <div class="d-flex align-items-center">
                                                    <p class="font-bold h6 mb-0">Nama Santri</p>
                                                </div>
                                            </td>
                                            <td class="col-auto">
                                                <p class=" mb-0">
                                                    <span class="profilepp" style="margin-left: 1rem">
                                                        : <?php echo e($namaSantri); ?>

                                                    </span>
                                                </p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="col-4">
                                                <div class="d-flex align-items-center">
                                                    <p class="font-bold h6 mb-0">Username Santri</p>
                                                </div>
                                            </td>
                                            <td class="col-auto">
                                                <p class=" mb-0">
                                                    <span class="profilepp" style="margin-left: 1rem">
                                                        : <?php echo e($usernameSantri); ?>

                                                    </span>
                                                </p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="col-4">
                                                <div class="d-flex align-items-center">
                                                    <p class="font-bold h6 mb-0">Kelas Santri</p>
                                                </div>
                                            </td>
                                            <td class="col-auto">
                                                <p class=" mb-0">
                                                    <span class="profilepp" style="margin-left: 1rem">
                                                        : <?php echo e($kelasSantri); ?>

                                                    </span>
                                                </p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="col-4">
                                                <div class="d-flex align-items-center">
                                                    <p class="font-bold h6 mb-0">Telepon Santri</p>
                                                </div>
                                            </td>
                                            <td class="col-auto">
                                                <p class=" mb-0"><span class="profilepp" style="margin-left: 1rem">:
                                                        <?php echo e($nohpSantri); ?></span>
                                                </p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="col-4">
                                                <div class="d-flex align-items-center">
                                                    <p class="font-bold h6 mb-0">Email Santri</p>
                                                </div>
                                            </td>
                                            <td class="col-auto">
                                                <p class=" mb-0"><span class="profilepp" style="margin-left: 1rem">:
                                                        <?php echo e($emailSantri); ?></span>
                                                </p>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="col-7">
                        <div class="card">
                            <div class="card-header">
                                <div class="card-title">
                                    <h6 class="d-flex justify-content-between align-items-center">
                                        <span>Tahun Ajaran: <b><?php echo e($thaktif->name); ?></b></span>
                                        <div class="ml-auto">Semester:
                                            <select class="" id="filterTahunAjaran">
                                                <option value="">Semester</option>
                                            </select>
                                        </div>

                                    </h6>
                                </div>
                            </div>

                            <div class="table-responsive">
                                <table class="table table-borderless" id="myTable">
                                    
                                </table>
                                <a onclick="refreshDataTable();"
                                    class="btn icon icon-left d-flex justify-content-center align-items-center">
                                    <span id="refreshText">REFRESH</span>
                                    <i id="refreshIcon" class="fas fa-sync fa-spin d-none"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

            </div>

            

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('user-script'); ?>
    <!-- Include Chart.js -->
    <script src="<?php echo e(asset('extensions/chart.js/chart.umd.min.js')); ?>"></script>
    <script src="<?php echo e(asset('extensions/chart.js/chartjs-plugin-datalabels.min.js')); ?>"></script>
    <script src="<?php echo e(asset('extensions/apexcharts/apexcharts.min.js')); ?>"></script>

    <script src="<?php echo e(asset('extensions/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('extensions/datatables.net-bs5/js/dataTables.bootstrap5.min.js')); ?>"></script>
    <?php echo $__env->make('user.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('user.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\newsiakad\resources\views/user/connect.blade.php ENDPATH**/ ?>