<div class="btn-group mb-1">
    <div class="dropdown">
        <div class="btn-group">
            <button class="btn btn-primary btn-sm dropdown-toggle me-1" type="button" id="dropdownMenuButtonIcon"
                data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="bi bi-error-circle me-50"></i> Action
            </button>
            <div class="dropdown-menu" aria-labelledby="dropdownMenuButtonIcon" style="">
                <a class="dropdown-item tombol-edit" href="#" data-id="<?php echo e($data->id); ?>"
                    data-user-type="<?php echo e($data->user_type); ?>">Edit</a>
                <a class="dropdown-item tombol-del" href="#" data-id="<?php echo e($data->id); ?>"
                    data-user-type="<?php echo e($data->user_type); ?>" data-name="<?php echo e($data->name); ?>">Delete</a>

                <?php if(auth()->user()->hasRole('admin') &&
                        in_array(request()->route()->getName(),
                            ['userAjax.index'])): ?>
                    <a class="dropdown-item tombol-login" href="#" data-id="<?php echo e($data->id); ?>"
                        data-user-type="<?php echo e($data->user_type); ?>" data-name="<?php echo e($data->name); ?>">
                        Login as <b><?php echo e($data->name); ?></b>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\newsiakad\resources\views/admin/tombol.blade.php ENDPATH**/ ?>