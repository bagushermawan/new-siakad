<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Raport</title>
</head>
<body>
    <h1>Raport</h1>

    <!-- Tambahkan link atau tombol untuk membuka PDF di tab baru -->
    <a href="<?php echo e(route('show.pdf', ['pdf_path' => $pdf_path])); ?>" target="_blank">Buka PDF di Tab Baru</a>

    <table border="1">
        <thead>
            <tr>
                <th>User ID</th>
                <th>Mata Pelajaran</th>
                <th>Kelas</th>
                <th>Tahun Ajaran</th>
                <th>Nilai</th>
                <th>Tahun Ajaran Semester</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo html_entity_decode($item['user_id']); ?></td>
                    <td><?php echo e($item['mata_pelajaran_id'] ?: 'Data Mata Pelajaran tidak tersedia'); ?></td>
                    <td><?php echo e($item['kelas_id']); ?></td>
                    <td><?php echo e($item['tahun_ajaran_id']); ?></td>
                    <td><?php echo e($item['nilai']); ?></td>
                    <td><?php echo e($item['tahun_ajaran_semester']); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\laragon\www\newsiakad\resources\views/test/data.blade.php ENDPATH**/ ?>