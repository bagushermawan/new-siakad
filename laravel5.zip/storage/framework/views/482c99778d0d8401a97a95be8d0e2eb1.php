<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Siakad</title>



    <link rel="shortcut icon" href="<?php echo e(asset('/compiled/svg/favicon.svg')); ?>" type="image/x-icon">
    <link rel="stylesheet" href="<?php echo e(asset('/compiled/css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/compiled/css/app-dark.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/compiled/css/auth.css')); ?>">
</head>

<body>
    <script src="<?php echo e(asset('/static/js/initTheme.js')); ?>"></script>
    <div id="auth">

        <!-- Session Status -->

        <div class="row h-100">
            <div class="col-lg-5 col-12">
                <div id="auth-left">
                    <div class="auth-logo">
                        <a href="/"><img src="<?php echo e(asset('/compiled/png/logodarunnajah.png')); ?>" alt="Logo"></a>
                    </div>
                    <h1 class="auth-title">Masuk.</h1>
                    <p class="auth-subtitle mb-5">Masuk dengan data Anda yang Anda masukkan saat pendaftaran.</p>
                    <?php if(session('status')): ?>
                        <div class="auth-subtitle mb-5" style="color:#198754;">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group position-relative has-icon-left mb-4">
                            <input type="text" class="form-control form-control-xl" id="id_user"
                                placeholder="Username atau Email" name="id_user" value="<?php echo e(old('id_user')); ?>" required
                                autofocus autocomplete="id_user">
                            <div class="form-control-icon">
                                <i class="bi bi-person"></i>
                            </div>
                            <?php $__errorArgs = ['id_user'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div style="color:#F8719D;"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <div class="form-group position-relative has-icon-left mb-4">
                            <input type="password" id="password" class="form-control form-control-xl"
                                placeholder="Kata Sandi" name="password" required autocomplete="current-password">
                            <div class="form-control-icon">
                                <i class="bi bi-shield-lock"></i>
                            </div>
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div style="color:#F8719D;"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-check form-check-lg d-flex align-items-end">
                            <input id="remember_me" class="form-check-input me-2" type="checkbox" name="remember"
                                value="">
                            <label class="form-check-label text-gray-600" for="remember_me">
                                Ingatkan saya
                            </label>
                        </div>
                        <button type="submit" class="btn btn-primary btn-block btn-lg shadow-lg mt-5">Masuk</button>
                    </form>
                    <div class="text-center mt-5 text-lg fs-4">
                        <p class="text-gray-600">Belum punya akun? <a href="<?php echo e(route('register')); ?>"
                                class="font-bold">Daftar disini</a>.</p>
                        <p><a class="font-bold" href="<?php echo e(route('password.request')); ?>">Lupa kata sandi?</a></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-7 d-none d-lg-block">
                <div id="auth-right">

                </div>
            </div>
        </div>

    </div>
</body>

</html>
<?php /**PATH C:\laragon\www\newsiakad\resources\views/auth/login.blade.php ENDPATH**/ ?>