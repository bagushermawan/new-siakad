
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>RAPORT PESERTA DIDIK</title>
  </head>
<body background-color="black;">
    <div class="Frame1" style="width: 1064px; height: 1480px; position: relative; border-radius: 5px; overflow: hidden; border: 1px #9747FF dotted">
  <div class="Property1Default" style="width: 1024px; height: 1440px; left: 20px; top: 20px; position: absolute; background: white">
    <div class="Border" style="width: 931px; height: 1355px; left: 46px; top: 39px; position: absolute; background: white; border: 10px black solid"></div>
    <div class="RaportPesertaDidikSekolahDasarSd" style="left: 275px; top: 122px; position: absolute; text-align: center; color: black; font-size: 40px; font-family: Inter; font-weight: 700; word-wrap: break-word">RAPORT PESERTA DIDIK<br/>SEKOLAH DASAR (SD)</div>
    <img class="PpaiDarunnajah1" style="width: 467px; height: 492px; left: 277px; top: 372px; position: absolute" src="https://via.placeholder.com/467x492" />
    <div class="PondokPesantrenDarunnajahKabupatenMalang" style="left: 153px; top: 247px; position: absolute; text-align: center; color: black; font-size: 40px; font-family: Inter; font-weight: 700; word-wrap: break-word">PONDOK PESANTREN DARUNNAJAH<br/>KABUPATEN MALANG</div>
    <div class="NamaPesertaDidik" style="width: 315px; height: 39px; left: 354px; top: 956px; position: absolute; text-align: center; color: black; font-size: 24px; font-family: Inter; font-weight: 700; word-wrap: break-word">Nama Peserta Didik:</div>
    <div class="Rectangle1" style="width: 373px; height: 59px; left: 325px; top: 1010px; position: absolute; background: white; border: 1px black solid"></div>
    <div class="BagusHermawan" style="left: 376px; top: 1020px; position: absolute; text-align: center; color: black; font-size: 32px; font-family: Inter; font-weight: 600; word-wrap: break-word">Bagus Hermawan</div>
    <div class="NisNisn" style="width: 175px; height: 38px; left: 423px; top: 1085px; position: absolute; text-align: center; color: black; font-size: 24px; font-family: Inter; font-weight: 700; word-wrap: break-word">NIS / NISN :</div>
    <div class="Rectangle2" style="width: 373px; height: 60px; left: 325px; top: 1139px; position: absolute; background: white; border: 1px black solid"></div>
    <div class="08" style="left: 456px; top: 1150px; position: absolute; text-align: center; color: black; font-size: 32px; font-family: Inter; font-weight: 600; word-wrap: break-word">19 / 08</div>
  </div>
</div>
</body>
</html>
